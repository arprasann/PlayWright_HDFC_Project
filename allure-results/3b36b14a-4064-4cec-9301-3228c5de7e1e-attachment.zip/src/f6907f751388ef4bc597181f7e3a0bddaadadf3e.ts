/**
 * Test Case: Login with Valid Credentials
 * 
 * Tags: @master @sanity @regression
 * 
 * Steps:
 * 1) Navigate to the application URL
 * 2) Navigate to Login page via Home page
 * 3) Enter valid credentials and log in
 * 4) Click on Logout Button
 */

import { test, expect } from '@playwright/test';
import { LoginPage1 } from '../pages/LoginPage';
import { TestConfig } from '../test.config';
import { HomePage } from '../pages/HomePage';
import { Tasks } from '../pages/Tasks';

let config: TestConfig;
let logPage: LoginPage1;
let homePage: HomePage;
let tasks : Tasks;

// This hook runs before each test
test.beforeEach(async ({ page }) => {
  config = new TestConfig(); // Load config (URL, credentials)
  await page.goto(config.appUrl); // Navigate to base URL

  // Initialize page objects
  logPage = new LoginPage1(page);
  homePage = new HomePage(page);
  tasks = new Tasks(page);
});

// Optional cleanup after each test
test.afterEach(async ({ page }) => {
  await page.close(); // Close browser tab (good practice in local/dev run)
});


test('Validate Tasks Page @master @sanity @regression',async()=>{

    //Enter valid credentials and log in
    await logPage.enterUserName(config.username)
    await logPage.enterPassword(config.password)
    await logPage.clickonLoginButton()

    await logPage.waitforsometime();

    await tasks.clickonTasks()

    await tasks.enterFilterTaskByName("Monday")

    await tasks.clickonApplyFilter();

 
     await homePage.clickonLogoutButton();

     await logPage.waitforsometime()
})
